print('Selecione uma comida')
print('=============================')
print('1 - Macarrão - R$15,00')
print('2 - Carne com mandioca - R$25,00')
print('3 - Strogonoff - R$15,00')
print('4 - Churrasco - R$30,00')
print('5 - Filé de frango - R$15,00')
print('6 - Bife acebolado - R$15,00')




print('=============================')

print('Selecione uma bebida')
print('=============================')
print('1 - Suco natural - R$10,00')
print('2 - Coca cola ks - R$5,00')
print('3 - Agua - R$2,00')
print('4 - Fanta Uva ks - R$5,00')
print('5 - Sprite - R$5,00')
print('6 - Guaraná Lata - R$6,00')




opcaoC = input("Digite o número da comida: ")
opcaoB = input("Digite o número da bebida: ")

if opcaoC == '1':
    valor_comida1 = 15
elif opcaoC =='2':
    valor_comida1 = 25
elif opcaoC == '3':
    valor_comida1 = 15
elif opcaoC == '4':
    valor_comida1 = 30
elif opcaoC == '5':
    valor_comida1 = 15
elif opcaoC == '6':
    valor_comida1 = 15
else:
    valor_comida1 = 0

if opcaoB =='1':
    valor_bebida1 = 10
elif opcaoB =='2':
    valor_bebida1 = 6
elif opcaoB == '3':
    valor_bebida1 = 2
elif opcaoB == '4':
    valor_bebida1 = 5
elif opcaoB == '5':
    valor_bebida1 = 5
elif opcaoB == '6':
    valor_bebida1 = 6
else:
    valor_bebida1 = 0

valor_total = valor_comida1 + valor_bebida1

if valor_comida1 == 0 or valor_bebida1 == 0:
    print('Número invalido! tente novamente ')

else:
    print(f'O valor total da sua conta é R${valor_total}')


